//نگین عینی پور-40223056
#include <stdio.h>
#include <string.h>
#include <ctype.h>
int main()
{
    int n;
    char lang1[10][10];
    char lang2[10][10];
    char sentence2[100][10];
    char sentence[100];
    char answer[100][100];
    scanf("%d",&n);
    getchar();
    for(int j=0; j<n; j++)
    {
        scanf("%s       %s",lang1[j],lang2[j]);
    }
    getchar();
    fgets(sentence, sizeof(sentence), stdin);



    if(isupper(lang1[0][0]))
    {
        for(int i=0; i<100; i++)
            sentence[i]=toupper(sentence[i]);
    }
    else
    {
        for(int i=0; i<100; i++)
            sentence[i]=tolower(sentence[i]);
    }



    int i=0, count=0;
    for(int k=0; (sentence[i]!='\n') && (sentence[i]!='\0'); k++)
    {
        while (sentence[i]==' ')
            i++;
        for (int j=0; (sentence[i]!='\n') && (sentence[i]!=' ') && (sentence[i]!='\0'); j++)
        {
            sentence2[k][j]=sentence[i];
            i++;
        }
        count++;
    }


    int k=0;
    while(k<count)
    {
        for(int j=0; j<n; j++)
        {
            int c=0;
            for(;(sentence2[k][c]!='\0') && (lang1[j][c]!='\0') && (lang2[j][c]!='\0') && (sentence2[k][c]==lang1[j][c] || sentence2[k][c]==lang2[j][c]);c++)
            {
                if (sentence2[k][c]!=lang1[j][c] && sentence2[k][c]!=lang2[j][c])
                    j++;
                else
                {
                if (strlen(lang2[j]) > strlen(lang1[j]))
                    strcpy(answer[k], lang1[j]);
                else if (strlen(lang2[j]) < strlen(lang1[j]))
                    strcpy(answer[k], lang2[j]);
                else
                    strcpy(answer[k], sentence2[k]);
                k++;
                }
            }
        }
    }
    



    for(int k=0;k<count;k++)
        printf("%s ",answer[k]);
}

